<!DOCTYPE html>
<html>
    <head>
        <!-- <link rel="stylesheet" href = "1.css"> -->
        <style>
            body{
                font-family: 'Courier New', Courier, monospace;
            }
            form input{
                display: block;
                /* line-height: 25px; */
                width: 500px;
            }
            form > *{
                display: block;
            }

            #sending{
                width: 100%;
            }

            div > *{
                display: table;
                margin-left: auto;
                margin-right: auto;
            }

            div{
                width: 100%;
            }
            span {
                display: inline-block;
                color: red;
                font-weight: bold;
            }
            #captcha{
                width: 100%;
                margin-top: 5px;
            }
            #heades{
                margin-top: 50px;
            }
            
        </style>
        <script src="https://smartcaptcha.yandexcloud.net/captcha.js" defer></script>
    </head>
    <body>
        <div id = "heades">
            <h1>Форма регистрации</h1>
            <form action method="post">
                <!--  Имя, телефон, почту, пароль и повтор пароля. -->
                <label><span id="pequi">*</span>Имя</label>
                <input type="text", placeholder="Иван" pattern="^[А-Яа-яЁё]+$" name="name" required>
    
                <label><span id="pequi">*</span>Номер телефона: </label>
                <input type="tel", placeholder="+7(XXX)-XXX-XX-XX" pattern="\+7\([0-9]{3}\)[0-9]{3}-[0-9]{2}-[0-9]{2}" name="nomer" required>
    
    
                <label><span id="pequi">*</span>Почта</label>
                <input type="email", placeholder="example@test.su"  name="email" required>
    
                <label><span id="pequi">*</span>Пароль</label>
                <input type="password" name="password_1" required>
    
                <label><span id="pequi">*</span>Повторение пароля</label>
                <input type="password" name="password_2">
                <div id="captcha">
                    <div
                        id="captcha-container"
                        class="smart-captcha"
                        data-sitekey="ysc1_hdTI4VsHOkrIUXhZQ3RxFLOH3LvF1Jz1LcNfR7xbe7b01b6a">
                    </div>
                </div>
                <?php
                /*Код, взятый с офиц. сайта Яндекс Каптчи (для подключения самой каптчи)*/
                    include '.\sql_config.php';

                    if(!empty($_POST)){

                        $name = $_POST['name'];
                        $email = $_POST['email'];
                        $nomer = $_POST['nomer'];
                        $password_1 = $_POST['password_1'];
                        $password_2 = $_POST['password_2'];

                        if ($password_1==$password_2){
                            $sql = new DB();
                            if($sql->error){
                                print_r("CONNECTION_ERROR! :(");
                            }
                            else{
                                if (!empty($_POST['smart-token'])){
                                    $bool_captcha = false; 

                                    $token = $_POST['smart-token'];
                                    $captcha = new Captcha(); //класс каптчи с sql_config по ООП
                                    if ($captcha->check_captcha($token)) {
                                        $bool_captcha=true;
                                    } else {
                                        $bool_captcha=false;
                                    }
                                    if ($bool_captcha=true){

                                        $strsql = "SELECT `name` FROM users_table WHERE `email`='$email'";
                                        $bool_email = $sql->unique($strsql);
                                        $strsql = "SELECT `name` FROM users_table WHERE `number`='$nomer'";
                                        $bool_nomer = $sql->unique($strsql);
                                        $strsql = "SELECT `name` FROM users_table WHERE `name`='$name'";
                                        $bool_login = $sql->unique($strsql);
                                        $strsql = "INSERT INTO `users_table` VALUES ('$name', '$nomer','$email',(SELECT MD5('$password_1')))"; 


                                        if($bool_email){
                                            echo "Почта должна быть уникальной!";
                                        }
                                        else if($bool_nomer){
                                            echo "Номер должен быть уникальным!";
                                        }
                                        else if($bool_login){
                                            echo "Логин из имени должен быть уникальным!";
                                        }
                                        else{
                                            $query = $sql->query($strsql);
                                            if ($query==true){
                                                echo "Регистрация выполнена успешно!";
                                            }
                                            $sql->close();
                                        }
                                    }
                                    else{
                                        echo "Вы робот! Команды роботов не выполняем!";
                                    }
                                }
                                else{
                                    echo "<label>Нажмите на каптчу!</label>";
                                }
                            }
                            $_POST=null;
                        }
                        else{
                            echo "<label>Пароли не совпадают!</label>";
                        }
                    }
                ?>

                <input type="submit" name="submit" value="SEND!" id="sending" required>
    
            </form>

        </div>
        
        

    </body>
</html>