<!DOCTYPE html>
<html>
    <head>
        <!-- <link rel="stylesheet" href = "1.css"> -->
        <script src="https://smartcaptcha.yandexcloud.net/captcha.js" defer></script>
        <style>
            body{
                font-family: 'Courier New', Courier, monospace;
            }
            form input{
                display: block;
                /* line-height: 25px; */
                width: 500px;
            }
            form > *{
                display: block;
            }

            #sending{
                width: 100%;
            }

            div > *{
                display: table;
                margin-left: auto;
                margin-right: auto;
            }

            div{
                width: 100%;
            }
            span {
                display: inline-block;
                color: red;
                font-weight: bold;
            }
            #captcha{
                width: 100%;
                margin-top: 5px;
            }
            #heades{
                margin-top: 50px;
            }
            
        </style>
    </head>
    <body>
        <div id = "heades">
        <?php

            require ".\sql_config.php";
            require ".\captcha_secret.php";

            $sql = new DB();

            $dynamic = $_GET['dynamic'];
            $password_1 = strtoupper(md5($_GET['password_1']));
            $password_2 = strtoupper(md5($_GET['password_2']));

            $dynamic_start_value = $dynamic[0].$dynamic[1];

            if ($password_1==$password_2){ // если пароли совпадают
                if ($_GET['smart-token']!=""){
                    if($dynamic_start_value=="+7"){
                        $strsql="SELECT `name` FROM `users_table` WHERE `password`='$password_1' AND `number`='$dynamic'";
                    }
                    else{
                        $strsql="SELECT `name` FROM `users_table` WHERE `password`='$password_1' AND `email`='$dynamic'";
                    }
        
                    $nameses = $sql->one_cell_sql($strsql,"name");
                    if (!isset($nameses)){
                        echo "Такого пользователя не существует.";
                        echo '<br><a href="index.php">На главную</a>';
                    }
                    else{
                        print_r($nameses);
                        print_r('<form action method="post"><label><span id="pequi">*</span>Имя</label><input type="text", placeholder="Иван" pattern="^[А-Яа-яЁё]+$" name="name" required><label><span id="pequi">*</span>Номер телефона: </label><input type="tel", placeholder="+7(XXX)-XXX-XX-XX" pattern="\+7\([0-9]{3}\)[0-9]{3}-[0-9]{2}-[0-9]{2}" name="nomer" required><label><span id="pequi">*</span>Почта</label><input type="email", placeholder="example@test.su"  name="email" required><label><span id="pequi">*</span>Пароль</label><input type="password" name="password_1" required><label><span id="pequi">*</span>Повторение пароля</label><input type="password" name="password_2"><div id="captcha"><div id="captcha-container" class="smart-captcha" data-sitekey="ysc1_hdTI4VsHOkrIUXhZQ3RxFLOH3LvF1Jz1LcNfR7xbe7b01b6a"></div></div><input type="submit" name="submit" value="SEND!" id="sending" required>');
                        if(!empty($_POST)){

                            $name = $_POST['name'];
                            $email = $_POST['email'];
                            $nomer = $_POST['nomer'];
                            $password_1 = $_POST['password_1'];
                            $password_2 = $_POST['password_2'];
    
                            if ($password_1==$password_2){
                                $sql = new DB();
                                if($sql->error){
                                    print_r("CONNECTION_ERROR! :(");
                                }
                                else{
                                    if (!empty($_POST['smart-token'])){
                                        $bool_captcha = false; 
    
                                        $token = $_POST['smart-token'];
                                        $captcha = new Captcha(); //класс каптчи с sql_config по ООП
                                        if ($captcha->check_captcha($token)) {
                                            $bool_captcha=true;
                                        } else {
                                            $bool_captcha=false;
                                        }
                                        if ($bool_captcha=true){
    
                                            $strsql = "SELECT `name` FROM users_table WHERE `email`='$email'";
                                            $bool_email = $sql->unique($strsql);
                                            $strsql = "SELECT `name` FROM users_table WHERE `number`='$nomer'";
                                            $bool_nomer = $sql->unique($strsql);
                                            $strsql = "SELECT `name` FROM users_table WHERE `name`='$name'";
                                            $bool_login = $sql->unique($strsql);
                                            $strsql = "UPDATE `users_table` SET `name`='$name',`number`='$nomer',`email`='$email',`password`=(SELECT(MD5('$password_1'))) WHERE `name`='$nameses'"; 
    
    
                                            if($bool_email){
                                                echo "Почта должна быть уникальной!";
                                            }
                                            else if($bool_nomer){
                                                echo "Номер должен быть уникальным!";
                                            }
                                            else if($bool_login){
                                                echo "Логин из имени должен быть уникальным!";
                                            }
                                            else{
                                                $query = $sql->query($strsql);
                                                if ($query==true){
                                                    echo "Изменение данных выполнено успешно! Войдите заново под изменёнными данными, тогда данные изменятся.";
                                                }
                                                else{
                                                    echo "error";
                                                }
                                                $sql->close();
                                            }
                                        }
                                        else{
                                            echo "Вы робот! Команды роботов не выполняем!";
                                        }
                                    }
                                    else{
                                        echo "<label>Нажмите на каптчу!</label>";
                                    }
                                }
                                $_POST=null;
                            }
                            else{
                                echo "<label>Пароли не совпадают!</label>";
                            }
                        }
                    }
        
                }
                else{
                    echo "Нет каптчи!";
                }
                
            }
            else{
                echo "Пароли не совпадают!";
            }
            
        ?>
        </div>

    </body>
</html>