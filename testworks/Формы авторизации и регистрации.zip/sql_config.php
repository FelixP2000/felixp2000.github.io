<?php

    // собственная библиотека, написанная собственноручно на основе инкапсуляции из ООП 

    require '.\captcha_secret.php';

    class DB{

        protected $hostname = "localhost";
        protected $username = "root";
        protected $password = "";
        protected $database = "users";

        public $error;
        protected $sqls;

        public function __construct() //объявление класса подключения
        {   
            $this->sqls = new mysqli($this->hostname,$this->username,null,$this->database);
            if($this->sqls->connect_error){
                $this->error=true;
            }
        }

        function unique($strsql){ //общий метод проверки на уникальность из пункта заданич про уникальность почты, телефона и т.д.
            $query = mysqli_query($this->sqls,$strsql);
            if (isset($query->fetch_assoc()['name'])){
                return true;
            }
            else{
                return false;
            }
        }

        function query($strsql){ //метод запроса, наследованный с mysqli_query
            $query = mysqli_query($this->sqls,$strsql);
            return $query;
        }

        function close(){ //метод закрытия
            $this->sqls->close();
        }
        function one_cell_sql($string_sql,$name_v){ // метод вывода текста при запросе SELECT `<одной переменной>`

            $query = mysqli_query($this->sqls, $string_sql);
            // $rslt = $query->fetch_assoc()["$name_v"];
            $rslt=null;
            $rslt=$query->fetch_assoc();

            if (!is_null($rslt)){
                $rslt=$rslt["$name_v"];
            }
            else{
                $rslt=null;
            }

            return $rslt;

        }
    }

    class Captcha { //класс каптчи. Здесь код указан с сайта Яндекса каптчи (для подключение самой каптчи)+ немного отредактирован
        private $server_key=null;

        public function __construct(){
            global $c_token;
            $this->server_key=$c_token;
        }

        public function check_captcha($token) {
            $ch = curl_init();
            $args = http_build_query([
                "secret" => $this->server_key,
                "token" => $token,
                "ip" => $_SERVER['REMOTE_ADDR'],
            ]);
            $url="https://smartcaptcha.yandexcloud.net/validate?$args";
            curl_setopt($ch, CURLOPT_URL, $url);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_TIMEOUT, 1);

            $server_output = curl_exec($ch);
            $httpcode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
            curl_close($ch);

            if ($httpcode !== 200) {
                // echo "Allow access due to an error: code=$httpcode; message=$server_output\n"; - данный код мне показался не нужным - поэтому убрал
                // без него и так проверка работает, я проверял
                return true;
            }
            $resp = json_decode($server_output);
            return $resp->status === "ok";
        }
    }
?>