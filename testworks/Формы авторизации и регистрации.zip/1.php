<!DOCTYPE html>
<html>
    <head>
        <!-- <link rel="stylesheet" href = "1.css"> -->
        <style>
            body{
                font-family: 'Courier New', Courier, monospace;
            }
            form input{
                display: block;
                /* line-height: 25px; */
                width: 500px;
            }
            form > *{
                display: block;
            }

            #sending{
                width: 100%;
            }

            div > *{
                display: table;
                margin-left: auto;
                margin-right: auto;
            }

            div{
                width: 100%;
            }
            span {
                display: inline-block;
                color: red;
                font-weight: bold;
            }
            #captcha{
                width: 100%;
                margin-top: 5px;
            }
            #heades{
                margin-top: 50px;
            }
            
        </style>
        <script src="https://smartcaptcha.yandexcloud.net/captcha.js" defer></script>
    </head>
    <body>
        <div id = "heades">
            <h1>Форма авторизации</h1>
            <form action="2.php" method="get" name="forma">
                <!--  Имя, телефон, почту, пароль и повтор пароля. -->
                <label><span id="pequi">*</span>Номер телефона или почта: </label>
                <input type="text" placeholder="+7(XXX)-XXX-XX-XX|example@test.su" pattern="[a-zA-Z_0-9.]+@[a-z]+.[a-z]{2,}|\+7\([0-9]{3}\)[0-9]{3}-[0-9]{2}-[0-9]{2}" name="dynamic" required>
    
                <label><span id="pequi">*</span>Пароль</label>
                <input type="password" name="password_1" required>
    
                <label><span id="pequi">*</span>Повторение пароля</label>
                <input type="password" name="password_2">
                <div id="captcha">
                    <div
                        id="captcha-container"
                        class="smart-captcha"
                        data-sitekey="ysc1_hdTI4VsHOkrIUXhZQ3RxFLOH3LvF1Jz1LcNfR7xbe7b01b6a">
                    </div>
                </div>
                <?php
                /*Код, взятый с офиц. сайта Яндекс Каптчи (для подключения самой каптчи)*/
                    require '.\sql_config.php'; // собственная библиотека, написанная по ООП для работы с БД
                    require ".\captcha_secret.php"; // ключ от каптчи

                    if(!empty($_GET)){

                        $dynamic = $_GET['dynamic'];
                        $password_1 = strtoupper(md5($_GET['password_1']));
                        $password_2 = strtoupper(md5($_GET['password_2']));

                        if ($password_1==$password_2){
                            $sql = new DB(); // класс установки подключение с БД по ООП
                            if($sql->error){
                                print_r("CONNECTION_ERROR! :(");
                            }
                            else{
                                if (!empty($_GET['smart-token'])){
                                    $bool_captcha = false; 

                                    $token = $_GET['smart-token'];
                                    $captcha=new Captcha();
                                    if ($captcha->check_captcha($token)) {
                                        $bool_captcha=true;
                                    } else {
                                        $bool_captcha=false;
                                    }
                                    if ($bool_captcha=true){

                                        $proverka=null;

                                        $dynamic_start_value = $dynamic[0].$dynamic[1];
                                        $strsql=null;

                                        if($dynamic_start_value=="+7"){
                                            $strsql="SELECT `name` FROM `users_table` WHERE `number`='$dynamic' AND `password`=$password_1'";
                                        }
                                        else{
                                            $strsql="SELECT `name` FROM `users_table` WHERE `email`='$dynamic' AND `password`='$password_1'";
                                        }


                                        $query = $sql->query($strsql);
                                        $boot_rslt=$sql->unique($strsql);

                                        if ($boot_rslt){
                                            echo "Авторизация выполнена успешно!";
                                            header('Location: 2.php');
                                        }
                                        else{
                                            echo "Неверные номер или почта, ну или пароль :(";
                                            // header('Location: 1.php');
                                        }
                                        $sql->close();
                                    }
                                    else{
                                        echo "Вы робот! Команды роботов не выполняем!";
                                    }
                                }
                                else{
                                    echo "<label>Нажмите на каптчу!</label>";
                                }
                            }
                            $_GET=null;
                        }
                        else{
                            echo "<label>Пароли не совпадают!</label>";
                        }
                    }
                ?>

                <input type="submit" name="submit" value="SEND!" id="sending" required>
    
            </form>

        </div>
        
        

    </body>
</html>