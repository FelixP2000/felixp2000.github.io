-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Хост: 127.0.0.1
-- Время создания: Мар 22 2024 г., 04:36
-- Версия сервера: 10.4.28-MariaDB
-- Версия PHP: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `users`
--

-- --------------------------------------------------------

--
-- Структура таблицы `users_table`
--

CREATE TABLE `users_table` (
  `name` text NOT NULL,
  `number` varchar(50) NOT NULL,
  `email` text NOT NULL,
  `password` longtext NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Дамп данных таблицы `users_table`
--

INSERT INTO `users_table` (`name`, `number`, `email`, `password`) VALUES
('Иван', '+7(911)768-81-30', 'felix12345@mail.ru', '529b1fd83e9b9d478b471004f175a973'),
('ИванТретий', '+7(911)768-81-67', 'felix999@mail.ru', '529b1fd83e9b9d478b471004f175a973'),
('ИванЧет', '+7(911)768-81-90', 'felix77777777@mail.ru', '529b1fd83e9b9d478b471004f175a973'),
('Феликсфел', '+7(911)768-81-55', 'felix888888888888888888888888@mail.ru', '529b1fd83e9b9d478b471004f175a973'),
('Михаилиирмиотл', '+7(911)768-00-00', 'ojihvjgbhkkl@mail.ru', '529b1fd83e9b9d478b471004f175a973'),
('Пётрпервый', '+7(911)700-10-10', 'petr1@mail.ru', '529b1fd83e9b9d478b471004f175a973'),
('ИванИванИванИванИван', '+7(900)000-00-00', 'test@gmil.com', '529b1fd83e9b9d478b471004f175a973'),
('ИванЧетвёртый', '+7(911)768-81-15', 'felixrussia@mail.ru', '6c996aa5db1b94fca44eb7788ad371fb');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
